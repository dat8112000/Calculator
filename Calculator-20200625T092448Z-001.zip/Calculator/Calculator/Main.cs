﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void cộngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCong f = new frmCong();
            f.MdiParent = this;
            f.Show();
            //this.MdiParent
        }

        private void trừToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTru f = new frmTru();
            f.MdiParent = this;
            f.Show();
        }

        private void nhânToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmNhan f = new frmNhan();
            f.MdiParent = this;
            f.Show();
        }

        private void chiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmChia f = new frmChia();
            f.MdiParent = this;
            f.Show();
        }
    }
}
