﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Calculator
{
    public partial class frmCong : Form
    {
        public frmCong()
        {
            InitializeComponent();
        }

        private void btnCong_Click(object sender, EventArgs e)
        {
            int s1 = int.Parse(txtSoThuNhat.Text);
            int s2 = int.Parse(txtSoThuHai.Text);
            lblKetQua.Text = (s1 + s2).ToString();
        }
    }
}
